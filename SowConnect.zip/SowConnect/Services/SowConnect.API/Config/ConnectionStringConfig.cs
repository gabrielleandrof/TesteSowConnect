﻿namespace SowConnect.API.Config
{
    public class ConnectionStringConfig
    {
        public string Default { get; set; }
    }
}